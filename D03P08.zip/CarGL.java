package com.learning.core.day3session2;

//import java.util.Collections;
import java.util.TreeMap;
	
public class CarGL {
		public static void main(String[] args) {
			
			
			TreeMap <String,Float> ca = new TreeMap<String,Float>();
			
			ca.put("Audi", 600100.0f);
			ca.put("Benz", 900000.0f);
			ca.put("Bugatti", 80050.0f);
			ca.put("Swift", 305000.0f);
			

			System.out.println(ca.higherEntry("Benz").getValue());
			
			
			System.out.println(ca.lowerEntry("Bugatti").getValue());
			
			
			
			}
			
			
			
		}


