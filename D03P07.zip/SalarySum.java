package com.learning.core.day3session1;

import java.util.Comparator;
import java.util.TreeSet;

public class SalarySum {

	public static void main(String[] args) {
		
		TreeSet <PersonS> pr = new TreeSet<PersonS>();

		PersonS ps1 = new PersonS(01, "Mariam", 45, 60000);

		PersonS ps2 = new PersonS(02, "Jammy", 26, 36000);

		PersonS ps3 = new PersonS(03, "sheeba", 22, 30000);

		PersonS ps4 = new PersonS(04, "ubaida", 40, 55000);

		PersonS ps5 = new PersonS(05, "Moiz", 20, 20000);

		PersonS ps6 = new PersonS(06, "saffiya", 21, 23000);

		pr.add(ps1);
		pr.add(ps2);
		pr.add(ps3);
		pr.add(ps4);
		pr.add(ps5);
		pr.add(ps6);

		 double slry = ((PersonS) Comparator.comparing(PersonS::getSalary)).sum();

	        
	        System.out.println("Sum of all salaries: " +slry );

	}

}
