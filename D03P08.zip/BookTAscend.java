package com.learning.core.day3session2;

import java.util.Collections;
import java.util.TreeSet;

public class BookTAscend {

	public static void main(String[] args) {
		
	    authorComparator ac = new authorComparator();
		
       TreeSet<Book1> bd = new TreeSet<Book1>(ac);
		
        bd.add(new Book1(1001, "Python Learning", 715.0f, "Martie C.Brown","02/02/2020"));
		bd.add(new Book1(1002, "Modern Mainframe", 295.0f, "Sharad","19/05/1997"));
		bd.add(new Book1(1003, "Java Programming", 523.0f, "Gilad Bracha","23/11/1984"));
		bd.add(new Book1(1004, "Read C++", 295.0f, "Henry Harvin","19/11/1984"));
		bd.add(new Book1(1005, ".Net Platform", 3497.0f, "Mark J.Price","06/03/1984"));

		//Collections.sort(bd, ac);
		for (Book1 b : bd) {
			System.out.println(b);
		
	}

	
		
		
	}

}
