package com.learning.core.day3session1;

import java.util.HashSet;

public class ListHashset {
	
	public static void main(String[] args) {
		
		HashSet<Product> p = new HashSet<Product>();
	
		Product p1 = new Product("P001", "Maruti 800");
		
		Product p2 = new Product("P002", "Maruti Zen");
		
		Product p3 = new Product("P003", "Maruti Dezire");
		
		Product p4 = new Product("P004", "Maruti Auto");
		
		p.add(p1);
		p.add(p2);
		p.add(p3);
		p.add(p4);
		
		//System.out.println(p);
		
		for(Product pdt:p) {
			
			System.out.println(pdt);
		}
		
	
	
	
	}
	
	
}
