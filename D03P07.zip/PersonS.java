package com.learning.core.day3session1;

import java.util.Objects;

	
	public class PersonS implements Comparable<PersonS>{
		
		
		public int Id;
		public String Name;
		public Integer Age;
		public double Salary;
		
		public PersonS() {
			super();
		}
		
		public PersonS(int Id, String Name, int Age, double Salary) {
			super();
			this.Id = Id;
			this.Name = Name;
			this.Age = Age;
			this.Salary = Salary;
		}
		public int getId() {
			return Id;
		}
		public void setId(int Id) {
			this.Id = Id;
		}
		public String getName() {
			return Name;
		}
		public void setName(String Name) {
			this.Name = Name;
		}
		public int getAge() {
			return Age;
		}
		public void setAge(int Age ) {
			this.Age = Age;
		}
		public double getSalary() {
			return Salary;
		}
		public void setSalary(double Salary) {
			this.Salary = Salary;
		}
		
		public void display() {
			System.out.println("Person Id :" +getId()+ "Person Name: "+getName()+
					 "Person age: "+getAge()+ "Person Salary: "+getSalary());
			
			
		}
			

		@Override
		public String toString() {
			return "Person [Id=" + Id + ", Name=" + Name + ", Age=" + Age + ", Salary=" + Salary + "]";
		}
		@Override
		public int compareTo(PersonS p) {
		
			//return Integer public int compareTo(Person other) {
		        return Integer.compare(this.Id, p.Id);
		
		}
		@Override
		public int hashCode() {
			return Objects.hash(Age, Id, Name, Salary);
		}
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			PersonS other = (PersonS) obj;
			return Objects.equals(Age, other.Age) && Id == other.Id && Objects.equals(Name, other.Name)
					&& Double.doubleToLongBits(Salary) == Double.doubleToLongBits(other.Salary);
		}

		public double sum() {
			// TODO Auto-generated method stub
			return 0;
		}
		

	}
