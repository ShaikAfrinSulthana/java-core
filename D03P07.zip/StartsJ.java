package com.learning.core.day3session1;

import java.util.Set;
import java.util.TreeSet;

public class StartsJ {
	    public static void main(String[] args) {
	     
	    	TreeSet <Person2> pr = new TreeSet<Person2>();

			Person2 ps1 = new Person2(01, "Mariam", 45, 60000);

			Person2 ps2 = new Person2(02, "Jammy", 26, 36000);

			Person2 ps3 = new Person2(03, "sheeba", 22, 30000);

			Person2 ps4 = new Person2(04, "ubaida", 40, 55000);

			Person2 ps5 = new Person2(05, "Moiz", 20, 20000);

			Person2 ps6 = new Person2(06, "saffiya", 21, 23000);

			pr.add(ps1);
			pr.add(ps2);
			pr.add(ps3);
			pr.add(ps4);
			pr.add(ps5);
			pr.add(ps6);


	        for (Person2 person : pr) {
	            if (person.getName().startsWith("J")) {
	                System.out.println(person);
	                break;
	            }else {
	            	System.out.println("It is Invalid");
	            	break;
	            }
	        }
	    }
	}

