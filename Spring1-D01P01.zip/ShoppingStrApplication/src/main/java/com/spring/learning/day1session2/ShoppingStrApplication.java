package com.spring.learning.day1session2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class ShoppingStrApplication {

	public static void main(String[] args) {
        System.out.println("Constructor Dependency Injection");
		System.out.println("Shopping Online : ");
		String config_file_loc = "/src/main/resources/applicationContext.xml";
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

		Battery b = (Battery) context.getBean("btryId");
		b.display();
		System.out.println(b);

		Disc d = (Disc) context.getBean("disId");
		d.display();
		System.out.println(d);
	}

}
