package com.learning.core.day3session1;

public class Person  {
	
	public int Id;
	public String Name;
	public Integer Age;
	public double Salary;
	
	
	
	public Person(int Id, String Name, int Age, double Salary) {
		super();
		this.Id = Id;
		this.Name = Name;
		this.Age = Age;
		this.Salary = Salary;
	}
	public int getId() {
		return Id;
	}
	public void setId(int Id) {
		this.Id = Id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String Name) {
		this.Name = Name;
	}
	public int getAge() {
		return Age;
	}
	public void setAge(int Age ) {
		this.Age = Age;
	}
	public double getSalary() {
		return Salary;
	}
	public void setSalary(double Salary) {
		this.Salary = Salary;
	}
	
	public void display() {
		System.out.println("Person Id :" +getId()+ "Person Name: "+getName()+
				 "Person age: "+getAge()+ "Person Salary: "+getSalary());
		
		
	}
	//@Override
	//public int compareTo(Person p) {
		
		//if(this.Age >= p.getAge())
		//return 0;
		//else if (this.Age > p.getAge())
		//return 1;
		//else return -1;
	//}
	
	
		

	@Override
	public String toString() {
		return "Person [Id=" + Id + ", Name=" + Name + ", Age=" + Age + ", Salary=" + Salary + "]";
	}

}


