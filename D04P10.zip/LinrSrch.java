package com.learning.core.day4session2;

import java.util.Scanner;

public class LinrSrch {

public void search (int arr[], int key) {
		
		boolean flag = false;
		
		for(int i= 0; i < arr.length; i++) {
			
			if(arr[i] == key) {
				
				flag = true;
				
				System.out.println("element found : " + i);
				
				break;
			}
			
		}
		
		if (flag == false) {
			
			
			
			System.out.println("element is absent ");
		}
}
		
	public static void main (String[] args) {
		
		//LinrSrch ls = new LinrSrch ();
		int arr[] = new int [5];
		Scanner sc = new Scanner (System.in);
		System.out.println("Enter 5 elements: ");
		for(int i= 0; i < arr.length; i++) 
		{
			arr[i] = sc.nextInt();
		}
	System.out.println("Enter the element to be searched: ");
	int key = sc.nextInt();
	int last = arr.length-1;
	LinrSrch ls = new LinrSrch();
	ls.search(arr, key);
	
	}

}
