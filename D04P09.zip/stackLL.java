package com.learning.core.day4session1;

import java.util.Scanner; 

class LinkedStack<T> { 
    // create a Node class 
    private class Node { 
  
        // A Node contains two parts inside it one is 'data' 
        // part and the other is 'next' which has a 
        // reference to the next Node 
        T data; 
        Node next; 
  
        // define a parameterized constructor which 
        // initializes the local variables of Node class 
        public Node(T data, Node next) 
        { 
            this.data = data; 
            this.next = next; 
        } 
  
        public String toString() 
        { 
            // returns the data in 
            // string format 
            return data.toString(); 
        } 
    } 
  
    // Here top acts as a reference to the Node 
    private Node top; 
    
    public boolean isEmpty()
    
    {
    	return top == null; 
    	
    } 
    public void push(T ele) 
    { 
        // Every time  when a new element is pushed onto the 
        // stack a new Node is created and top is pointed to 
        // it 
        top = new Node(ele, top); 
    } 
  
    public T pop() 
    { 
  
        // check if elements present on Stack or not 
        if (top == null) 
            return null; 
        else { 
            // if present do the following 
            // Assign the topmost element of 
            // stack into a variable 
            T element = top.data; 
            // make top to point it's next 
            // node 
            top = top.next; 
            // Popped element is returned to 
            // the main 
            return element; 
        } 
    } 
  
    public T peek() 
    { 
        // return the element which is 
        // at beginning of the stack 
        return top.data; 
    } 
  
    public int size() 
    { 
        // This method returns the no.of elements present on 
        // the stack 
        int count = 0; 
        Node temp = top; 
  
        while (temp != null) { 
            // increment count 
            count += 1; 
            // make temp to point it's 
            // next Node 
            temp = temp.next; 
        } 
  
        return count; 
    } 
  
    public void display() 
    { 
        // This method displays every element of the Stack 
        // LinkedList 
        System.out.println( 
            "The elements of the stack are: "); 
        Node temp = top; 
        while (temp != null) { 
            // print the data in 'temp' 
            System.out.print(temp.data + "::"); 
            // make temp to point it's 
            // next Node 
            temp = temp.next; 
        } 
        // indicates that last Node is not 
        // pointing to any Node 
        System.out.println("null"); 
  
        System.out.println(); 
    } 
} 
  
// main method 
public class stackLL { 
  
 
    public static void main(String[] args) 
    { 
        // create an object of LinkedStack 
        LinkedStack<Double> ls = new LinkedStack<>(); 
  
        
        ls.push(10.0); 
  
        
        ls.push(20.0); 
  
        
        ls.display(); 
  
        ls.push(30.0); 
        ls.push(40.0); 
  
        System.out.println( "After pushing 10.0,20.0,30.0,40.0"); 
  
        ls.display(); 
  
        // pop element from stack(40.0 is popped 
        // out) 
        ls.pop(); 
  
        // 30.0 is popped out 
        // printing the stack after poping the elements 
        ls.pop(); 
  
        System.out.println("after pop() operation"); 
        ls.display(); 
    }
}