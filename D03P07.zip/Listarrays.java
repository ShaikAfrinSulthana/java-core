package com.learning.core.day3session1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Listarrays {
	

		public static void main(String[] args) {
		
			
			List list = new ArrayList();
			list.add("Jack");
			list.add("Paul");
			list.add("Henry");
			list.add("Mary");
			list.add("Ronaldo");
			
			System.out.println(list);
			
			//for(Object o:list) {
				
				//System.out.println(o);
			//}
			Scanner in = new Scanner(System.in);
			System.out.print("Enter the Name: ");
			String name = in.nextLine();
			
			if(list.contains(name)) {
				System.out.println(name + " is Found");
			}else {
			//System.out.println(list.contains("Henry"));
			System.out.println(name +" is Not Found");
			}
		}

}
