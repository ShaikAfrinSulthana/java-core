package com.learning.core.day3session2;

import java.util.Collections;
import java.util.TreeMap;
	


public class CarDes {
		public static void main(String[] args) {
			
			
			TreeMap <String,Float> ca = new TreeMap<String,Float>(Collections.reverseOrder());
			
			ca.put("Audi", 600100.0f);
			ca.put("Benz", 900000.0f);
			ca.put("Bugatti", 80050.0f);
			ca.put("Swift", 305000.0f);
			
			System.out.println("Elements in Reverse : ");
			
			for (String unKey: ca.keySet()) {
				System.out.println("Car: " + unKey + ", Price: " + ca.get(unKey));
			}
			
			
			
		}

	}
