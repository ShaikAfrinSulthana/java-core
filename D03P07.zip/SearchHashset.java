package com.learning.core.day3session1;

import java.util.HashSet;
import java.util.Scanner;


public class SearchHashset {
	
	public static void main(String[] args) {
		
    HashSet p = new HashSet();
    
      p.add("P001, Maruti 800");
      p.add("P002, Maruti Zen");
      p.add("P003, Maruti Dezire");
      p.add("P004, Maruti Auto");
    
		//System.out.println(p);
		
		//for(Product pdt:p) {
			
			//System.out.println(pdt);
			
			Scanner in = new Scanner(System.in);
			System.out.print("Enter the Name:");
			String prdt = in.nextLine();
			
			if(p.contains(prdt)) {
				System.out.println(prdt + " is Found");
			}else {
			
			System.out.println(prdt +" is Not Found");
		}
	}
}
