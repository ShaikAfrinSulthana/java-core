package com.learning.core.day3session1;

import java.util.TreeSet;
import java.util.Comparator;

public class Treesetperson {

	public static void main(String[] args) {

		TreeSet <Person> pr = new TreeSet<>(new ThirdComparator());

			Person ps1 = new Person(01, "Mariam", 45, 60000);

			Person ps2 = new Person(02, "Maria", 26, 36000);

			Person ps3 = new Person(03, "sheeba", 22, 30000);

			Person ps4 = new Person(04, "ubaida", 40, 55000);

			Person ps5 = new Person(05, "Moiz", 20, 20000);

			Person ps6 = new Person(06, "saffiya", 21, 23000);

			pr.add(ps1);
			pr.add(ps2);
			pr.add(ps3);
			pr.add(ps4);
			pr.add(ps5);
			pr.add(ps6);


   		for (Person p: pr)
   			p.display();
  

	}

}
