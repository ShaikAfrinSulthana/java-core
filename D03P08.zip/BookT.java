package com.learning.core.day3session2;

//import java.text.SimpleDateFormat;
import java.util.TreeSet;

public class BookT {

	
	public static void main(String[] args) {
		
		//SimpleDateFormat format = new SimpleDateFormat("mm/dd/yyyy");
		
		TreeSet<Book> bd = new TreeSet<Book>();
		
		Book b1 = new Book(1001, "Python Learning", 715.0f, "Martie C.Brown","02/02/2020");
		Book b2 = new Book(1002, "Modern Mainframe", 295.0f, "Sharad","19/05/1997");
		Book b3 = new Book(1003, "Java Programming", 523.0f, "Gilad Bracha","23/11/1984");
		Book b4 = new Book(1004, "Read C++", 295.0f, "Henry Harvin","19/11/1984");
		Book b5 = new Book(1005, ".Net Platform", 3497.0f, "Mark J.Price","06/03/1984");
		
		bd.add(b1);
		bd.add(b2);
		bd.add(b3);
		bd.add(b4);
		bd.add(b5);
		
		
		System.out.println(bd);
		
	}
	
}


