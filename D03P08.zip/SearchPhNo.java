package com.learning.core.day3session2;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class SearchPhNo {
	
	public static void main(String[] args) {
		
		Map<String,Long> pb = new HashMap<String,Long>();
		
		pb.put("Amal", (long) 998787823);
		pb.put("Manvitha", (long) 937843978);
		pb.put("Joseph", (long) 788222113);
		pb.put("Smith", (long) 918895823);
		pb.put("Zaraar", (long) 998787823);
		
		System.out.println(pb);
		

		               

		                Scanner scanner = new Scanner(System.in);
		        System.out.print("Enter a name to search: ");
		        String searchName = scanner.nextLine();

		                Long phoneNumber = pb.get(searchName);

		                if (phoneNumber != null) {
		            System.out.println("Phone number for " + searchName + ": " + phoneNumber);
		        } else {
		            System.out.println("No phone number found for " + searchName);
		        }
		    }
		
		
		
		
	}
