package com.learning.core.day3session2;

import java.util.Objects;

public class Car implements Comparable <Car> {
	
	private String carName;
	private Float carPrice;
	
	
	public Car(String carName, Float carPrice) {
		super();
		this.carName = carName;
		this.carPrice = carPrice;
	}


	@Override
	public int hashCode() {
		return Objects.hash(carName, carPrice);
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Car other = (Car) obj;
		return Objects.equals(carName, other.carName) && Objects.equals(carPrice, other.carPrice);
	}


	@Override
	public String toString() {
		return "Car [carName=" + carName + ", carPrice=" + carPrice + "]";
	}


	@Override
	public int compareTo(Car o) {
		// TODO Auto-generated method stub
		return 4;
	}
	
	
	
	

	
	

}
