package com.learning.core.day3session2;

import java.util.TreeMap;

public class CarReplace {
	
public static void main(String[] args) {
		
		
		TreeMap <String,Integer> ca = new TreeMap<String, Integer>();
		
		ca.put("Audi", 600100);
		ca.put("Benz", 900000);
		ca.put("Bugatti", 80050);
		ca.put("Swift", 305000);
		
		System.out.println("Initial Mappings: " + ca);
		
		ca.remove("Bugatti",80050);
		ca.put("Reva", 80050);

		
		for(String key: ca.keySet()) {
			
			System.out.println(key+" , "+ ca.get(key));
		}

}
}
