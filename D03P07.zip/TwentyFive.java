package com.learning.core.day3session1;

import java.util.Set;
import java.util.TreeSet;

	public class TwentyFive {
		    public static void main(String[] args) {
		     
		    	TreeSet <PersonG> pr = new TreeSet<PersonG>();

				PersonG ps1 = new PersonG(01, "Mariam", 45, 60000);

				PersonG ps2 = new PersonG(02, "zaibah", 26, 36000);

				PersonG ps3 = new PersonG(03, "sheeba", 22, 30000);

				PersonG ps4 = new PersonG(04, "ubaida", 40, 55000);

				PersonG ps5 = new PersonG(05, "Moiz", 20, 20000);

				PersonG ps6 = new PersonG(06, "saffiya", 21, 23000);

				pr.add(ps1);
				pr.add(ps2);
				pr.add(ps3);
				pr.add(ps4);
				pr.add(ps5);
				pr.add(ps6);

				

		        for (PersonG person : pr) {
		            if (((PersonG) person).getAge() > 25) {
		                System.out.println(person);
		            }
		        }
		    }
		}
