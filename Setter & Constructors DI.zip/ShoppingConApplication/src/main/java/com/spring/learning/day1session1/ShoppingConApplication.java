package com.spring.learning.day1session1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class ShoppingConApplication {

	public static void main(String[] args) {
        System.out.println("Constructor Dependency Injection");
		System.out.println("Shopping Online : ");
		String config_file_loc = "/src/main/resources/applicationContextt.xml";
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContextt.xml");

		Battery b = (Battery) context.getBean("btryId");
		b.display();
		System.out.println(b);

		Disc d = (Disc) context.getBean("disId");
		d.display();
		System.out.println(d);
	}

}
