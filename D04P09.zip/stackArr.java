package com.learning.core.day4session1;

import java.util.Stack;

public class stackArr {
	
	
public static void main(String[] args) {
	
	Stack<String> s = new Stack<String>();
	
	s.push("Hello");
	s.push("World");
	s.push("Java");
	s.push("Programming");
	
	System.out.println("Elements pushed are : " +s);
	
	s.pop();
	
	System.out.println("Elements after removing elements : " +s);
	
	
	

	}

}
