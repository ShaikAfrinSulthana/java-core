package com.spring.learning.day1session2;

public class Disc extends Product{

	private int capacity;

	public Disc() {
		super(102, "disc", 2000);

	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	@Override
	public String toString() {
		return "Disc [capacity=" + capacity + "]";
	}






}
