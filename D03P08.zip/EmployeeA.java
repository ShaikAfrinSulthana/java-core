package com.learning.core.day3session2;

import java.util.Hashtable;

public class EmployeeA {

	public static void main(String[] args) {
		
		 Hashtable<Integer,Employee> e = new Hashtable<Integer, Employee>();
			
			Employee e1 = new Employee(1,"Bushra","IT","Senior Engineer");
			Employee e2 = new Employee(2,"Shawn","BPO","Manager");
			Employee e3 = new Employee(3,"Allen","Marketing","Data Analyst");
			Employee e4 = new Employee(4,"Zehra","Testing","Test Engineer");
					
			e.put(1, e1);
			e.put(2, e2);
			e.put(3, e3);
			e.put(4, e4);
			
			System.out.println("Initial Mapping: " + e);
			
		
			

	}

}
