package com.learning.core.day3session1;

import java.util.TreeSet;

public class UpperTreeset {
	
	public static void main(String[] args) {
		
		TreeSet <Person1> pr = new TreeSet<Person1>();

		Person1 ps1 = new Person1(01, "Mariam", 45, 60000);

		Person1 ps2 = new Person1(02, "Maria", 26, 36000);

		Person1 ps3 = new Person1(03, "sheeba", 22, 30000);

		Person1 ps4 = new Person1(04, "ubaida", 40, 55000);

		Person1 ps5 = new Person1(05, "Moiz", 20, 20000);

		Person1 ps6 = new Person1(06, "saffiya", 21, 23000);

		pr.add(ps1);
		pr.add(ps2);
		pr.add(ps3);
		pr.add(ps4);
		pr.add(ps5);
		pr.add(ps6);


		for (Person1 p: pr)
		{
			System.out.println(p.getName().toUpperCase());
			
		}
	
	
	}
	
	

}
