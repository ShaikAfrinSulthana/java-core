package com.spring.learning.day1session1;


public class Battery extends Product {

	private boolean rechargeable;


	public Battery() {
		super(101, "battery", 4000);

	}
	
	


	public Battery(int pid, String pname, int price, boolean rechargeable) {
		super(pid, pname, price);
		this.rechargeable = rechargeable;
	}




	public boolean isRechargeable() {
		return rechargeable;
	}


	public void setRechargeable(boolean rechargeable) {
		this.rechargeable = rechargeable;
	}


	@Override
	public String toString() {
		return "Battery [rechargeable=" + rechargeable + "]";
	}


}



